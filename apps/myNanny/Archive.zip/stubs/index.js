const Stubs = {
  chores:
    "{walking the dog|cleaning my room|taking a shower|" +
    "washing dishes|making my bed|doing my homework|" +
    "taking a nap|sweeping the floor|feeding the dog|" +
    "cooking dinner|eating a snack|cleaning the bathroom|" +
    "watering the plants|doing laundry|doing the laundry|" +
    "taking out the trash|taking out the garbage|throwing out the trash|" +
    "throwing out the garbage|mowing the lawn|washing the car|" +
    "cleaning the car|weeding the garden|shampooing the carpet|" +
    "winterizing the house|coding my thesis project|coding|programming|CHORE}",

  names:
    "{eugene|meredith|luis|robin|oleg|tom|hans|david|dave|daniel|tony|FIRSTNAME}"
};

module.exports = Stubs;