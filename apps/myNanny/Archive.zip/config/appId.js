module.exports = {
	value: "amzn1.ask.skill.d09cc0c6-064c-4c48-8930-c8cee1d10a78"
};
