module.exports = {
  SID: "ACf9d0deb352d5a28fa001176e57c76fa6",
  Token: "06f57c68d34494f46322f9acc319dc57"
};
